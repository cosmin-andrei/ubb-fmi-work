Comenzi:
lex lex-analizer.l
bison yacc-parser.y
gcc lex.yy.c yacc-parser.tab.c -o executabilg