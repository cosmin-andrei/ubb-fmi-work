package com.example.myapp.todo.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.myapp.todo.ui.item.convertDateToString
import java.util.Date

@Entity(tableName = "items")
data class Item(
    @PrimaryKey val _id: String = "",
    val title: String = "",
    val description: String="",
    val date: String = convertDateToString(Date()),
    val participants: Int = 0,
    val status: Boolean = false
)
