package com.example.myapp.auth.data.remote

data class TokenHolder(
    val token: String
)
