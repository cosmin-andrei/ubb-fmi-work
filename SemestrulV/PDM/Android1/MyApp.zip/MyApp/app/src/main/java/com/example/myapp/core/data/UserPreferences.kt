package com.example.myapp.core.data

data class UserPreferences(val username: String = "", val token: String = "")
