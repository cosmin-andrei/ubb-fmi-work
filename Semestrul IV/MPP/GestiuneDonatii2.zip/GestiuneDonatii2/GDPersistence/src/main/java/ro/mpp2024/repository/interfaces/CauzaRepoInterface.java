package ro.mpp2024.repository.interfaces;

import ro.mpp2024.model.Cauza;
import ro.mpp2024.repository.Repository;

import java.util.Optional;

public interface CauzaRepoInterface extends Repository<Long, Cauza> {

    Optional<Cauza> findByNume(String nume);

}
