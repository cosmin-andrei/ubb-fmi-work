package ro.mpp2024.repository;

import ro.mpp2024.model.Cauza;
import ro.mpp2024.repository.interfaces.CauzaRepoInterface;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

public class CauzaRepo implements CauzaRepoInterface {

    private final JdbcUtils dbUtils;

    public CauzaRepo(Properties props) {
        dbUtils = new JdbcUtils(props);
    }

    @Override
    public Optional<Cauza> findOne(Long aLong) {
        Connection con = dbUtils.getConnection();
        try (PreparedStatement preStmt = con.prepareStatement("select * from Cauza where id=?")) {
            preStmt.setLong(1, aLong);
            try (ResultSet result = preStmt.executeQuery()) {
                if (result.next()) {
                    Cauza cauza = new Cauza(result.getString("nume"), result.getString("descriere"));
                    cauza.setId(aLong);
                    return Optional.of(cauza);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error DB " + e);
        }
        return Optional.empty();
    }

    @Override
    public Iterable<Cauza> findAll() {
        Connection con = dbUtils.getConnection();
        List<Cauza> cauze = new ArrayList<>();
        try (PreparedStatement preStmt = con.prepareStatement("select * from Cauza")) {
            try (ResultSet result = preStmt.executeQuery()) {
                while (result.next()) {
                    Long id = result.getLong("id");
                    Cauza cauza = new Cauza(result.getString("nume"), result.getString("descriere"));
                    cauza.setId(id);
                    cauze.add(cauza);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error DB " + e);
        }

        return cauze;
    }

    @Override
    public Optional<Cauza> save(Cauza entity) {
        return Optional.empty();
    }

    @Override
    public Optional<Cauza> delete(Long aLong) {
        return Optional.empty();
    }

    @Override
    public Optional<Cauza> update(Cauza entity) {
        return Optional.empty();
    }

    @Override
    public Optional<Cauza> findByNume(String nume) {
        Connection con = dbUtils.getConnection();
        try (PreparedStatement preStmt = con.prepareStatement("select * from Cauza where nume=?")) {
            preStmt.setString(1, nume);
            try (ResultSet result = preStmt.executeQuery()) {
                if (result.next()) {
                    Cauza cauza = new Cauza(result.getString("nume"), result.getString("descriere"));
                    cauza.setId(result.getLong("id"));
                    return Optional.of(cauza);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error DB " + e);
        }
        return Optional.empty();
    }
}
