package ro.mpp2024.repository;

import ro.mpp2024.model.Donator;
import ro.mpp2024.repository.interfaces.DonatorRepoInterface;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

public class DonatorRepo implements DonatorRepoInterface {
    private final JdbcUtils dbUtils;

    public DonatorRepo(Properties props) {
        this.dbUtils = new JdbcUtils(props);
    }

    @Override
    public Optional<Donator> findOne(Long aLong) {
        Connection con = dbUtils.getConnection();
        try (PreparedStatement preStmt = con.prepareStatement("select * from Donator where id=?")) {
            preStmt.setLong(1, aLong);
            ResultSet result = preStmt.executeQuery();
            if (result.next()) {
                Donator donator = new Donator(result.getString("nume"), result.getLong("telefon"), result.getString("adresa"));
                donator.setId(aLong);
                return Optional.of(donator);
            }
        } catch (SQLException e) {
            System.out.println("Error DB " + e);
        }
        return Optional.empty();
    }


    @Override
    public Iterable<Donator> findAll() {
        Connection con = dbUtils.getConnection();
        List<Donator> donatori = new ArrayList<>();
        try (PreparedStatement preStmt = con.prepareStatement("select * from Donator")) {
            ResultSet result = preStmt.executeQuery();
            while (result.next()) {
                Long id = result.getLong("id");
                Donator donator = new Donator(result.getString("nume"), result.getLong("telefon"), result.getString("adresa"));
                donator.setId(id);
                donatori.add(donator);
            }
        } catch (SQLException e) {
            System.out.println("Error DB " + e);
        }

        return donatori;
    }

    @Override
    public Optional<Donator> save(Donator entity) {
        Connection con = dbUtils.getConnection();
        try (PreparedStatement preStmt = con.prepareStatement("insert into Donator values (?, ?, ?, ?)")) {
            preStmt.setLong(1, entity.getId());
            preStmt.setString(2, entity.getNume());
            preStmt.setLong(3, entity.getTelefon());
            preStmt.setString(4, entity.getAdresa());
            int result = preStmt.executeUpdate();
            if (result > 0) {
                return Optional.empty();
            }
        } catch (SQLException e) {
            System.out.println("Error DB " + e);
        }
        return Optional.empty();
    }

    @Override
    public Optional<Donator> delete(Long aLong) {
        return Optional.empty();
    }

    @Override
    public Optional<Donator> update(Donator entity) {
        return Optional.empty();
    }


    @Override
    public Optional<Donator> findDonator(String nume) {
        Connection con = dbUtils.getConnection();
        try (PreparedStatement preStmt = con.prepareStatement("select * from Donator where nume=?")) {
            preStmt.setString(1, nume);
            try (ResultSet result = preStmt.executeQuery()) {
                if (result.next()) {
                    Donator donator = new Donator(result.getString("nume"), result.getLong("telefon"), result.getString("adresa"));
                    donator.setId(result.getLong("id"));
                    return Optional.of(donator);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error DB " + e);
        }
        return Optional.empty();
    }
}
