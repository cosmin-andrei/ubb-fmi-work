package ro.mpp2024.repository;

import ro.mpp2024.model.Voluntar;
import ro.mpp2024.repository.interfaces.VoluntarRepoInterface;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

public class VoluntarRepo implements VoluntarRepoInterface {

    private JdbcUtils dbUtils;

    public VoluntarRepo(Properties props) {
        dbUtils = new JdbcUtils(props);
    }

    @Override
    public Optional<Voluntar> findOne(Long aLong) {
        Connection con = dbUtils.getConnection();
        try (PreparedStatement preStmt = con.prepareStatement("select * from \"Voluntar\" where id=?")) {
            preStmt.setLong(1, aLong);
            try (ResultSet result = preStmt.executeQuery()) {
                if (result.next()) {
                    Voluntar voluntar = getVoluntar(result);
                    return Optional.of(voluntar);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error DB " + e);
        }

        return Optional.empty();
    }

    @Override
    public Iterable<Voluntar> findAll() {
        Connection con = dbUtils.getConnection();
        List<Voluntar> voluntari = new ArrayList<>();
        try (PreparedStatement preStmt = con.prepareStatement("select * from Voluntar")) {
            try (ResultSet result = preStmt.executeQuery()) {
                while (result.next()) {
                    Voluntar voluntar = getVoluntar(result);
                    voluntari.add(voluntar);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error DB " + e);
        }
        return voluntari;
    }

    private static Voluntar getVoluntar(ResultSet result) throws SQLException {
        Long id = result.getLong("id");
        String username = result.getString("username");
        String nume = result.getString("nume");
        String email = result.getString("email");
        Long telefon = result.getLong("telefon");
        String parola = result.getString("parola");
        Voluntar voluntar = new Voluntar(username, parola);
        voluntar.setNume(nume);
        voluntar.setEmail(email);
        voluntar.setTelefon(telefon);
        voluntar.setId(id);
        return voluntar;
    }

    @Override
    public Optional<Voluntar> save(Voluntar entity) {
        return Optional.empty();
    }

    @Override
    public Optional<Voluntar> delete(Long aLong) {
        return Optional.empty();
    }

    @Override
    public Optional<Voluntar> update(Voluntar entity) {
        return Optional.empty();
    }

    @Override
    public Optional<Voluntar> verifyLogin(String username, String password) {
        Connection con = dbUtils.getConnection();
        try (PreparedStatement preStmt = con.prepareStatement("select * from \"Voluntar\" where username=? and parola=?")) {
            preStmt.setString(1, username);
            preStmt.setString(2, password);
            try (ResultSet result = preStmt.executeQuery()) {
                if (result.next()) {
                    Voluntar voluntar = getVoluntar(result);
                    return Optional.of(voluntar);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error DB " + e);
        }

        return Optional.empty();
    }

    @Override
    public Optional<Voluntar> findByUsername(String username) {
        Connection con = dbUtils.getConnection();
        try (PreparedStatement preStmt = con.prepareStatement("select * from \"Voluntar\" where username=?")) {
            preStmt.setString(1, username);
            try (ResultSet result = preStmt.executeQuery()) {
                if (result.next()) {
                    Voluntar voluntar = getVoluntar(result);
                    return Optional.of(voluntar);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error DB " + e);
        }

        return Optional.empty();
    }
}
