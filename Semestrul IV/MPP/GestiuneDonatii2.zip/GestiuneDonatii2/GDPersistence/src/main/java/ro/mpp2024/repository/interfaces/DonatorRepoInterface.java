package ro.mpp2024.repository.interfaces;

import ro.mpp2024.model.Donator;
import ro.mpp2024.repository.Repository;

import java.util.Optional;

public interface DonatorRepoInterface extends Repository<Long, Donator> {

    Optional<Donator> findDonator(String nume);
}
