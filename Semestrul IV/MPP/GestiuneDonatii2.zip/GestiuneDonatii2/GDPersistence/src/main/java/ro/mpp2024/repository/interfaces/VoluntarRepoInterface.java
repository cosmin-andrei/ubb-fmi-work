package ro.mpp2024.repository.interfaces;
import ro.mpp2024.model.Voluntar;
import ro.mpp2024.repository.Repository;

import java.util.Optional;

public interface VoluntarRepoInterface extends Repository<Long, Voluntar> {

    Optional<Voluntar> verifyLogin(String username, String password);
    Optional<Voluntar> findByUsername(String username);

}
