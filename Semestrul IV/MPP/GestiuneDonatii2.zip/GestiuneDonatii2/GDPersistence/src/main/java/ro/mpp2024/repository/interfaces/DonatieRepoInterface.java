package ro.mpp2024.repository.interfaces;

import ro.mpp2024.model.Donatie;
import ro.mpp2024.repository.Repository;

public interface DonatieRepoInterface extends Repository<Long, Donatie> {
}
