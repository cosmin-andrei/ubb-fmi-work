package ro.mpp2024.repository;

import ro.mpp2024.model.Cauza;
import ro.mpp2024.model.Donatie;
import ro.mpp2024.model.Donator;
import ro.mpp2024.repository.interfaces.DonatieRepoInterface;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

public class DonatieRepo implements DonatieRepoInterface {

    private final JdbcUtils dbUtils;

    public DonatieRepo(Properties props) {
        this.dbUtils = new JdbcUtils(props);
    }
    @Override
    public Optional<Donatie> findOne(Long aLong) {
        return Optional.empty();
    }

    @Override
    public Iterable<Donatie> findAll() {
        Connection con = dbUtils.getConnection();
        List<Donatie> donatii = new ArrayList<>();
        try (PreparedStatement preStmt = con.prepareStatement("select * from Donatie")) {
            ResultSet result = preStmt.executeQuery();
            while(result.next()) {
                Long id = result.getLong("id");
                Long idCauza = result.getLong("id_cauza");
                Long idDonator = result.getLong("id_donator");
                Timestamp data = result.getTimestamp("data");
                Float suma = result.getFloat("suma");
                Cauza cauza = new Cauza(null, null);
                cauza.setId(idCauza);
                Donator donator = new Donator(null, null, null);
                donator.setId(idDonator);
                Donatie donatie = new Donatie(donator, cauza, suma);
                donatie.setData(data);
                donatie.setId(id);
                donatii.add(donatie);
            }
            preStmt.execute();
        } catch (SQLException e) {
            System.out.println("Error DB " + e);
        }

        return donatii;
    }

    @Override
    public Optional<Donatie> save(Donatie entity) {
        Connection con = dbUtils.getConnection();
        try(PreparedStatement preStmt=con.prepareStatement("insert into Donatie values (?,?,?,?,?)")){
            preStmt.setLong(1,entity.getId());
            preStmt.setLong(2,entity.getCauza().getId());
            preStmt.setLong(3,entity.getDonator().getId());
            preStmt.setTimestamp(4,entity.getData());
            preStmt.setFloat(5,entity.getSuma());
            preStmt.executeUpdate();
            return Optional.of(entity);
        }catch (SQLException e){
            System.out.println("Error DB "+e);
        }
        return Optional.empty();
    }

    @Override
    public Optional<Donatie> delete(Long aLong) {
        return Optional.empty();
    }

    @Override
    public Optional<Donatie> update(Donatie entity) {
        return Optional.empty();
    }
}
