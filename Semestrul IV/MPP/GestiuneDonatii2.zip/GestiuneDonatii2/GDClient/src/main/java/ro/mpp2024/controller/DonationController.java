package ro.mpp2024.controller;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import ro.mpp2024.model.Cauza;
import ro.mpp2024.model.Donatie;
import ro.mpp2024.model.Donator;
import ro.mpp2024.networking.dto.DonatieDTO;
import ro.mpp2024.service.IObserver;
import ro.mpp2024.service.IServices;
import ro.mpp2024.service.ServiceException;

import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;

public class DonationController implements Initializable, IObserver {

    ObservableList<Donator> model = FXCollections.observableArrayList();
    @FXML
    private TableView<Donator> tblDonatori;
    @FXML
    TableColumn<Donator, String> lblNume;
    @FXML
    TableColumn<Donator, String> lblAdresa;
    @FXML
    TableColumn<Donator, String> lblTelefon;
    @FXML
    private TextField txtNume;
    @FXML
    private TextField txtAdresa;
    @FXML
    private TextField txtTelefon;
    @FXML
    private TextField txtSuma;
    @FXML
    private TextField txtDonator;
    private IServices service;
    private Stage dialogStage;
    private Cauza cauza;

    public void receiveUpdates() throws Exception {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        channel.queueDeclare("updates", false, false, false, null);
        channel.basicConsume("updates", true, (consumerTag, delivery) -> {
            String message = new String(delivery.getBody(), StandardCharsets.UTF_8);
            Platform.runLater(() -> processMessage(message));
        }, consumerTag -> {});
    }

    private void processMessage(String message) {
        // Aici trebuie să procesezi mesajul și să actualizezi UI-ul
        System.out.println("Received update: " + message);
        // Parse message and update the UI accordingly
    }


    public DonationController() {
        System.out.println("Mesaj constructor DonationController");
    }

    public void setService(IServices service, Cauza cauza, Stage dialogStage) throws ServiceException {
        this.service = service;
        this.cauza = cauza;
        this.dialogStage = dialogStage;
        initmodel();
        initialize();

        txtDonator.textProperty().addListener((observable, oldValue, newValue) -> {
            try {
                filterDonatoriList(newValue);
            } catch (ServiceException e) {
                throw new RuntimeException(e);
            }
        });
    }

    private void filterDonatoriList(String newValue) throws ServiceException {
        if (newValue.isEmpty()) {
            initmodel();
        } else {
            ObservableList<Donator> donatoriFiltrati = FXCollections.observableArrayList();
            for (Donator donator : model) {
                if (donator.getNume().toLowerCase().contains(newValue.toLowerCase())) {
                    donatoriFiltrati.add(donator);
                }
            }
            model.setAll(donatoriFiltrati);
        }
    }

    private void initmodel() throws ServiceException {
        model.setAll(service.getDonatori());
        tblDonatori.setItems(model);
    }

    private void initialize() {
        lblNume.setCellValueFactory(new PropertyValueFactory<>("nume"));
        lblAdresa.setCellValueFactory(new PropertyValueFactory<>("adresa"));
        lblTelefon.setCellValueFactory(new PropertyValueFactory<>("telefon"));
        tblDonatori.setItems(model);
    }

    @FXML
    private void handleRowSelection() {
        Donator donator = tblDonatori.getSelectionModel().getSelectedItem();
        if (donator != null) {
            txtNume.setText(donator.getNume());
            txtAdresa.setText(donator.getAdresa());
            txtTelefon.setText(String.valueOf(donator.getTelefon()));
        } else {
            txtNume.clear();
            txtAdresa.clear();
            txtTelefon.clear();
        }

    }

    public void handleAdd() {
        if (txtNume.getText().isEmpty() || txtAdresa.getText().isEmpty() || txtTelefon.getText().isEmpty()) {
            MessageAlert.showErrorMessage(null, "Completati toate campurile");
        } else {
            try {
                String Nume = txtNume.getText();
                String Adresa = txtAdresa.getText();
                Long Telefon = Long.parseLong(txtTelefon.getText());
                float Suma = Float.parseFloat(txtSuma.getText());
                Donator d = new Donator(Nume, Telefon, Adresa);
                d.setId(0L);
                if (service.findDonator(d) == null) {
                    service.addDonator(d);
                    Donator donator = service.findDonator(d);
                    System.out.println(donator.getNume());
                    Donatie donatie = new Donatie(donator, cauza, Suma);
                    donatie.setId(0L);
                    service.addDonatie(donatie);
//                    dialogStage.close();
                } else {
                    Donator donator = service.findDonator(d);
                    Donatie donatie = new Donatie(donator, cauza, Suma);
                    donatie.setId(0L);
                    service.addDonatie(donatie);
//                    dialogStage.close();
                }

            } catch (Exception e) {
                MessageAlert.showErrorMessage(null, e.getMessage());
                e.printStackTrace();
            }
        }
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    @Override
    public void newDonation(Donatie donatie) throws ServiceException {

    }

    @Override
    public void newDonator(Donator donator) throws ServiceException {
        Platform.runLater(() -> {
            model.add(donator);
            System.out.println("Donator added " + donator.getNume());
        });
    }
}
