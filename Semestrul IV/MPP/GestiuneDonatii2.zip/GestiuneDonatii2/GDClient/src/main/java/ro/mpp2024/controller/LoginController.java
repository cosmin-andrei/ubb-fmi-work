package ro.mpp2024.controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import ro.mpp2024.model.Voluntar;
import ro.mpp2024.service.IServices;
import ro.mpp2024.service.ServiceException;

import java.io.IOException;

public class LoginController {

    private IServices server;
    private UserController userController;

    private Voluntar voluntar;
    @FXML
    private TextField txtUsername;
    @FXML
    private TextField txtPassword;

    public void setServer(IServices server) {
        this.server = server;
    }

    public void setUserController(UserController userController) {
        this.userController = userController;
    }

    public void handleLogin(ActionEvent actionEvent) throws ServiceException {
        if (txtUsername.getText().isEmpty()) {
            MessageAlert.showErrorMessage(null, "Introdu un username");
        } else if (txtPassword.getText().isEmpty()) {
            MessageAlert.showErrorMessage(null, "Introdu o parola");
        } else {

            String username = txtUsername.getText();
            String password = txtPassword.getText();
            Voluntar voluntar = new Voluntar(username, password);

            try {

                FXMLLoader userLoader = new FXMLLoader();
                userLoader.setLocation(getClass().getResource("/user-view.fxml"));
                AnchorPane root = userLoader.load();

                UserController userController = userLoader.getController(); // Inițializare userController
                server.login(voluntar, userController);

                System.out.println("Login succeeded ...");
//                this.voluntar = server.findByUsername(username);

                userController.setServer(server);
                userController.setUser(voluntar);

                Stage userStage = new Stage();
                userStage.setTitle("User: " + voluntar.getUsername());
                userStage.initModality(Modality.WINDOW_MODAL);
                Scene scene = new Scene(root);
                userStage.setScene(scene);

                userStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                    @Override
                    public void handle(WindowEvent event) {
                        userController.logout();
                        System.exit(0);
                    }
                });

                userStage.show();

                ((Node) (actionEvent.getSource())).getScene().getWindow().hide();

            } catch (ServiceException e) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Gestiune donatii");
                alert.setHeaderText("Authentication failure");
                alert.setContentText("Wrong username or password");
                alert.showAndWait();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }
    }



}

