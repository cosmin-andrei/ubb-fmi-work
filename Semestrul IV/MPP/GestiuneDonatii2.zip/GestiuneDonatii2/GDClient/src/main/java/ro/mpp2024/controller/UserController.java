package ro.mpp2024.controller;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import ro.mpp2024.model.Cauza;
import ro.mpp2024.model.Donatie;
import ro.mpp2024.model.Donator;
import ro.mpp2024.model.Voluntar;
import ro.mpp2024.networking.dto.DonatieDTO;
import ro.mpp2024.service.IObserver;
import ro.mpp2024.service.IServices;
import ro.mpp2024.service.ServiceException;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;

public class UserController implements Initializable, IObserver {

    @FXML
    private TableView<DonatieDTO> tblDonatii;
    @FXML
    TableColumn<DonatieDTO, String> lblNume;
    @FXML
    TableColumn<DonatieDTO, Float> lblSuma;
    ObservableList<DonatieDTO> model = FXCollections.observableArrayList();
    private IServices server;
    private Voluntar user;


    public UserController() {
        System.out.println("Mesaj UserController constructor");
    }

    public void setServer(IServices service) throws ServiceException {
        this.server = service;
        initmodel();
        initialize();
    }

    public void setUser(Voluntar user) {
        this.user = user;
    }


    private void initialize() {
        lblNume.setCellValueFactory(new PropertyValueFactory<>("nume"));
        lblSuma.setCellValueFactory(new PropertyValueFactory<>("suma"));
        tblDonatii.setItems(model);
    }

    private void initmodel() throws ServiceException {
        HashMap<String, Float> donatii = server.getAllDonatii();
        List<DonatieDTO> donatieDTOList = new ArrayList<>();
        for (String nume : donatii.keySet()) {
            String numeCuMajuscula = nume.substring(0, 1).toUpperCase() + nume.substring(1);
            donatieDTOList.add(new DonatieDTO(numeCuMajuscula, donatii.get(nume)));

        }
        model.setAll(donatieDTOList);
        tblDonatii.setItems(model);
    }

    public void handleAdd(ActionEvent actionEvent) throws ServiceException {
        DonatieDTO donatie = tblDonatii.getSelectionModel().getSelectedItem();
        if (donatie != null) {
            Cauza cauza = server.findByNume(new Cauza(donatie.getNume(), ""));
            System.out.println(cauza.getDescriere());
            showAddDonatie(cauza);
        } else {
            MessageAlert.showErrorMessage(null, "Selectati o cauza");
        }
    }

    private void showAddDonatie(Cauza cauza) {

        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/donatieView.fxml"));

            AnchorPane root1 = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Adauga donatie");
            dialogStage.initModality(Modality.WINDOW_MODAL);

            dialogStage.setResizable(true);
            Scene scene = new Scene(root1, 600, 300);
            dialogStage.setScene(scene);

            DonationController donationController = loader.getController();
            donationController.setService(server, cauza, dialogStage);

            dialogStage.show();


        } catch (Exception e) {
            MessageAlert.showErrorMessage(null, "Eroare: " + e.getMessage());
            e.printStackTrace();
        }
    }

    void logout() {
        try {
            server.logout(user, this);
        } catch (ServiceException e) {
            System.out.println("Logout error " + e);
        }

    }

    public void handleLogout(ActionEvent actionEvent) {
        logout();
        ((Node) (actionEvent.getSource())).getScene().getWindow().hide();
    }

    @Override
    public void newDonation(Donatie donatie) throws ServiceException {

        Platform.runLater(() -> {
            System.out.println("Mesaj runLater newDonation "+ donatie);
            for (DonatieDTO donatieDTO : model) {
                if (donatieDTO.getNume().equals(donatie.getCauza().getNume())) {
                    donatieDTO.setSuma(donatieDTO.getSuma() + donatie.getSuma());
                    System.out.println("Intru in if");
                    break;
                }
            }
            System.out.println(model);
            tblDonatii.setItems(model);
            tblDonatii.refresh();
        });

    }


    @Override
    public void newDonator(Donator donator) throws ServiceException {

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
