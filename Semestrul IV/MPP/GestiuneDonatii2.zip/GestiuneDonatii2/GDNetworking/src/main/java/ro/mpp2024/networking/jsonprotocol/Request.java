package ro.mpp2024.networking.jsonprotocol;

import ro.mpp2024.model.Cauza;
import ro.mpp2024.model.Donatie;
import ro.mpp2024.model.Donator;
import ro.mpp2024.model.Voluntar;
import ro.mpp2024.networking.dto.DonatieDTO;
import ro.mpp2024.networking.dto.UserDTO;

import java.util.List;

public class Request {

    private RequestType type;
    private UserDTO user;
    private List<Donator> donatori;
    private Donator donator;
    private Donatie donatie;
    private Cauza cauza;

    public Request(){}
    public RequestType getType() {
        return type;
    }

    public void setType(RequestType type) {
        this.type = type;
    }

    public UserDTO getVoluntar() {
        return user;
    }

    public void setVoluntar(UserDTO voluntar) {
        this.user = voluntar;
    }

    public void setDonatori(List<Donator> donatori) {
        this.donatori=donatori;
    }

    public List<Donator> getDonatori() {
        return donatori;
    }

    public void setDonator(Donator donator) {
        this.donator = donator;
    }

    public Donator getDonator() {
        return this.donator;
    }

    public void setDonatie(Donatie donatie) {
        this.donatie = donatie;
    }

    public Donatie getDonatie() {
        return donatie;
    }

    public void setCauza(Cauza cauza) {
        this.cauza= cauza;
    }

    public Cauza getCauza() {
        return cauza;
    }
}
