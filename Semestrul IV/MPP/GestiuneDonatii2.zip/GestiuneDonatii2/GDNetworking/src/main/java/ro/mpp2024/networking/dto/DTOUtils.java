package ro.mpp2024.networking.dto;

import ro.mpp2024.model.Voluntar;

import java.util.HashMap;

public class DTOUtils {

    public static Voluntar getFromDTO(UserDTO usdto){
        String id=usdto.getId();
        String pass=usdto.getPasswd();
        return new Voluntar(id, pass);

    }
    public static UserDTO getDTO(Voluntar user){
        String id=user.getUsername();
        String pass=user.getParola();
        return new UserDTO(id, pass);
    }

    public static HashMap<String, Float> getFromDTODonatii(DonatieDTO[] donatiiDTO) {

        HashMap<String, Float> donatii = new HashMap<>();
        for (DonatieDTO donatieDTO : donatiiDTO) {
            donatii.put(donatieDTO.getNume(), donatieDTO.getSuma());
        }
        return donatii;
    }
}
