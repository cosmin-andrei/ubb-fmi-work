package ro.mpp2024.networking.jsonprotocol;

import com.google.gson.Gson;
import ro.mpp2024.model.Cauza;
import ro.mpp2024.model.Donatie;
import ro.mpp2024.model.Donator;
import ro.mpp2024.model.Voluntar;
import ro.mpp2024.networking.dto.DTOUtils;
import ro.mpp2024.networking.dto.UserDTO;
import ro.mpp2024.service.IObserver;
import ro.mpp2024.service.IServices;
import ro.mpp2024.service.ServiceException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;

public class GDClientJsonWorker implements Runnable, IObserver {
    private IServices server;
    private Socket connection;

    private BufferedReader input;
    private PrintWriter output;
    private Gson gsonFormatter;
    private volatile boolean connected;
    public GDClientJsonWorker(IServices server, Socket connection) {
        this.server = server;
        this.connection = connection;
        gsonFormatter=new Gson();
        try{
            output=new PrintWriter(connection.getOutputStream());
            input=new BufferedReader(new InputStreamReader(connection.getInputStream()));
            connected=true;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        while(connected){
            try {
                String requestLine=input.readLine();
                Request request=gsonFormatter.fromJson(requestLine, Request.class);
                Response response=handleRequest(request);
                if (response!=null){
                    sendResponse(response);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        try {
            input.close();
            output.close();
            connection.close();
        } catch (IOException e) {
            System.out.println("Error "+e);
        }
    }

    private static Response okResponse=JsonProtocolUtils.createOkResponse();

    private Response handleRequest(Request request) {
        Response response=null;

        try {
            switch (request.getType()) {
                case LOGIN:
                    UserDTO user = request.getVoluntar();
                    Voluntar voluntar = DTOUtils.getFromDTO(user);
                    server.login(voluntar, this);
                    response = okResponse;
                    break;
                case GET_DONATIONS:
                    HashMap<String, Float> donations = server.getAllDonatii();
                    response = JsonProtocolUtils.createGetDonationsResponse(donations);
                    break;
                case GET_DONATORI:
                    List<Donator> donatori = server.getDonatori();
                    response = JsonProtocolUtils.createGetDonatoriResponse(donatori);
                    break;
                case NEW_DONATOR:
                    server.addDonator(request.getDonator());
//                    newDonator(request.getDonator());
                    response = okResponse;
                    break;
                case FIND_DONATOR:
                    Donator donator = server.findDonator(request.getDonator());
                    response = JsonProtocolUtils.createFindDonatorResponse(donator);
                    break;
                case NEW_DONATION:
                    server.addDonatie(request.getDonatie());
//                    newDonation(request.getDonatie());
                    response = okResponse;
                    break;
                case FIND_CAUZA:
                    Cauza cauza = server.findByNume(request.getCauza());
                    response = JsonProtocolUtils.createFindCauzaResponse(cauza);
                    break;
                case LOGOUT:
                    UserDTO logoutUser = request.getVoluntar();
                    Voluntar logoutVoluntar = DTOUtils.getFromDTO(logoutUser);
                    server.logout(logoutVoluntar, this);
                    connected = false;
                    response = okResponse;
                    break;
            }
        } catch (ServiceException e) {
            response = JsonProtocolUtils.createErrorResponse(e.getMessage());
        }

        return response;
    }

    private void sendResponse(Response response) throws IOException{
        String responseLine=gsonFormatter.toJson(response);
        System.out.println("sending response "+responseLine);
        synchronized (output) {
            output.println(responseLine);
            output.flush();
        }
    }

    @Override
    public void newDonation(Donatie donatie) throws ServiceException {
        Response resp= JsonProtocolUtils.createNewDonationResponse(donatie);
        System.out.println("New donation response "+resp);
        try {
            sendResponse(resp);
        } catch (IOException e) {
            throw new ServiceException("Sending error: "+e);
        }
    }

    @Override
    public void newDonator(Donator donator) throws ServiceException {
        Response resp= JsonProtocolUtils.createNewDonatorResponse(donator);
        System.out.println("New donator response "+resp);
        try {
            sendResponse(resp);
        } catch (IOException e) {
            throw new ServiceException("Sending error: "+e);
        }

    }
}
