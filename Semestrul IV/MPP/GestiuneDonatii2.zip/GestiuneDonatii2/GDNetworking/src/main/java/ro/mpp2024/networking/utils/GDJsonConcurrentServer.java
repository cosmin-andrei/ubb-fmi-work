package ro.mpp2024.networking.utils;

import ro.mpp2024.networking.jsonprotocol.GDClientJsonWorker;
import ro.mpp2024.service.IServices;

import java.net.Socket;

public class GDJsonConcurrentServer extends AbsConcurrentServer {

    private IServices server;
    public GDJsonConcurrentServer(int port, IServices server) {
        super(port);
        this.server = server;
        System.out.println("Chat- ChatJsonConcurrentServer");
    }

    @Override
    protected Thread createWorker(Socket client) {
        GDClientJsonWorker worker=new GDClientJsonWorker(server, client);

        Thread tw=new Thread(worker);
        return tw;
    }

}
