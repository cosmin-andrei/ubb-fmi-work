package ro.mpp2024.networking.dto;

public class DonatieDTO {

    private String nume;
    private float suma;

    public DonatieDTO(String nume, float suma) {
        this.nume = nume;
        this.suma = suma;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public float getSuma() {
        return suma;
    }

    public void setSuma(float suma) {
        this.suma = suma;
    }
}
