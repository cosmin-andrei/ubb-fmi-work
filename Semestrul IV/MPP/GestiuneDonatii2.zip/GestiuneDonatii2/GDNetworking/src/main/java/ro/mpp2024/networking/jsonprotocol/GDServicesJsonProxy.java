package ro.mpp2024.networking.jsonprotocol;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import ro.mpp2024.model.Cauza;
import ro.mpp2024.model.Donatie;
import ro.mpp2024.model.Donator;
import ro.mpp2024.model.Voluntar;
import ro.mpp2024.service.IObserver;
import ro.mpp2024.service.IServices;
import ro.mpp2024.service.ServiceException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class GDServicesJsonProxy implements IServices {
    private String host;
    private int port;

    private IObserver client;

    private BufferedReader input;
    private PrintWriter output;
    private Gson gsonFormatter;
    private Socket connection;

    private BlockingQueue<Response> qresponses;
    private volatile boolean finished;

    public GDServicesJsonProxy(String host, int port) throws ServiceException {
        this.host = host;
        this.port = port;
        qresponses = new LinkedBlockingQueue<Response>();
    }

    public void login(Voluntar user, IObserver client) throws ServiceException {
        initializeConnection();

        Request req = JsonProtocolUtils.createLoginRequest(user);
        sendRequest(req);
        Response response = readResponse();
        if (response.getType() == ResponseType.OK) {
            this.client = client;
            new Thread(() -> {
                try {
                    client.receiveUpdates();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
            System.out.println(client);
            return;
        }
        if (response.getType() == ResponseType.ERROR) {
            String err = response.getErrorMessage();
            closeConnection();
            throw new ServiceException(err);
        }
    }



    public void logout(Voluntar user, IObserver client) throws ServiceException {

        Request req = JsonProtocolUtils.createLogoutRequest(user);
        sendRequest(req);
        Response response = readResponse();
        closeConnection();
        if (response.getType() == ResponseType.ERROR) {
            String err = response.getErrorMessage();//data().toString();
            throw new ServiceException(err);
        }
    }


    private void closeConnection() {
        finished = true;
        try {
            input.close();
            output.close();
            connection.close();
            client = null;
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void sendRequest(Request request) throws ServiceException {
        String reqLine = gsonFormatter.toJson(request);
        try {
            output.println(reqLine);
            output.flush();
            System.out.println("Request sent " + reqLine);
        } catch (Exception e) {
            throw new ServiceException("Error sending object " + e);
        }

    }

    private Response readResponse() throws ServiceException {
        Response response = null;
        try {

            response = qresponses.take();

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return response;
    }

    private void initializeConnection() throws ServiceException {
        try {
            gsonFormatter = new GsonBuilder()
                    .serializeNulls()
                    .create();
            connection = new Socket(host, port);
            output = new PrintWriter(connection.getOutputStream());
            output.flush();
            input = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            finished = false;
            startReader();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void startReader() {
        Thread tw = new Thread(new ReaderThread());
        tw.start();
    }


    public void receiveUpdates() throws Exception {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        channel.queueDeclare("updates", false, false, false, null);
        channel.basicConsume("updates", true, (consumerTag, delivery) -> {
            String message = new String(delivery.getBody(), StandardCharsets.UTF_8);
            Platform.runLater(() -> processMessage(message));
        }, consumerTag -> {});
    }

    private void processMessage(String message) {
        // Aici trebuie să procesezi mesajul și să actualizezi UI-ul
        System.out.println("Received update: " + message);
        // Parse message and update the UI accordingly
    }


    private void handleUpdate(Response response) {

        if (response.getType() == ResponseType.NEW_DONATOR) {
            Donator donator = response.getDonator();
            System.out.println("Donator nou " + donator);
            try {
                client.newDonator(donator);
            } catch (ServiceException e) {
                e.printStackTrace();
            }
        }

        if (response.getType() == ResponseType.NEW_DONATION) {
            Donatie donatie = response.getDonatie();
            System.out.println("Donatie noua " + donatie);
            try {
                client.newDonation(donatie);
            } catch (ServiceException e) {
                e.printStackTrace();
            }
        }

    }

    private boolean isUpdate(Response response) {
        return response != null && (response.getType() == ResponseType.NEW_DONATION || response.getType() == ResponseType.NEW_DONATOR);
    }


    @Override
    public void addDonator(Donator donator) throws ServiceException {
        Request req = JsonProtocolUtils.createAddDonatorRequest(donator);
        sendRequest(req);
        Response response = readResponse();
        if (response.getType() == ResponseType.OK) {
            return;
        }
        if (response.getType() == ResponseType.ERROR) {
            String err = response.getErrorMessage();//data().toString();
            throw new ServiceException(err);
        }
    }

    @Override
    public List<Donator> getDonatori() throws ServiceException {
        Request req = JsonProtocolUtils.createGetDonatoriRequest();
        sendRequest(req);
        Response response = readResponse();
        if (response.getType() == ResponseType.ERROR) {
            String err = response.getErrorMessage();//data().toString();
            throw new ServiceException(err);
        }
        return response.getDonatori();
    }

    @Override
    public HashMap<String, Float> getAllDonatii() throws ServiceException {
        Request req = JsonProtocolUtils.createDonatiiRequest();
        sendRequest(req);
        Response response = readResponse();
        if (response.getType() == ResponseType.ERROR) {
            String err = response.getErrorMessage();//data().toString();
            throw new ServiceException(err);
        }
        return response.getDonatii();
    }

    @Override
    public Donator findDonator(Donator donator) throws ServiceException {
        Request req = JsonProtocolUtils.createFindDonatorRequest(donator);
        sendRequest(req);
        Response response = readResponse();
        if (response.getType() == ResponseType.ERROR) {
            String err = response.getErrorMessage();//data().toString();
            throw new ServiceException(err);
        }
        return response.getDonator();
    }

    @Override
    public void addDonatie(Donatie donatie) throws ServiceException {
        Request req = JsonProtocolUtils.createNewDonationRequest(donatie);
        sendRequest(req);
        Response response = readResponse();
        if (response.getType() == ResponseType.ERROR) {
            String err = response.getErrorMessage();
            throw new ServiceException(err);
        }
    }

    @Override
    public Cauza findByNume(Cauza cauza) throws ServiceException {
        Request req = JsonProtocolUtils.createFindCauzaRequest(cauza);
        sendRequest(req);
        Response response = readResponse();
        if (response.getType() == ResponseType.ERROR) {
            String err = response.getErrorMessage();//data().toString();
            throw new ServiceException(err);
        }
        return response.getCauza();
    }

    private class ReaderThread implements Runnable {
        public void run() {
            while (!finished) {
                try {
                    String responseLine = input.readLine();
                    System.out.println("response received " + responseLine);
                    Response response = gsonFormatter.fromJson(responseLine, Response.class);
                    if (isUpdate(response)) {
                        handleUpdate(response);
                    } else {
                        try {
                            System.out.printf(String.valueOf(response));
                            qresponses.put(response);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                } catch (IOException e) {
                    System.out.println("Reading error " + e);
                }
            }
        }
    }
}

