package ro.mpp2024.networking.jsonprotocol;


import ro.mpp2024.model.Cauza;
import ro.mpp2024.model.Donatie;
import ro.mpp2024.model.Donator;
import ro.mpp2024.model.Voluntar;
import ro.mpp2024.networking.dto.DTOUtils;

import java.util.HashMap;
import java.util.List;

public class JsonProtocolUtils {

    public static Request createLoginRequest(Voluntar user) {
        Request req = new Request();
        req.setType(RequestType.LOGIN);
//        VoluntarDTO userDTO=new VoluntarDTO(user.getUsername(),user.getParola());
        req.setVoluntar(DTOUtils.getDTO(user));
        return req;
    }

    public static Response createErrorResponse(String errorMessage) {
        Response resp = new Response();
        resp.setType(ResponseType.ERROR);
        resp.setErrorMessage(errorMessage);
        return resp;
    }

    public static Response createOkResponse() {
        Response resp = new Response();
        resp.setType(ResponseType.OK);
        return resp;
    }

    public static Request createLogoutRequest(Voluntar voluntar) {
        Request req = new Request();
        req.setType(RequestType.LOGOUT);
        req.setVoluntar(DTOUtils.getDTO(voluntar));
        return req;
    }

    public static Request createDonatiiRequest() {
        Request req = new Request();
        req.setType(RequestType.GET_DONATIONS);
        return req;
    }

    public static Response createGetDonationsResponse(HashMap<String, Float> donations) {
        Response resp = new Response();
        resp.setType(ResponseType.GET_DONATIONS);
        resp.setDonatii(donations);
        return resp;
    }

    public static Request createGetDonatoriRequest() {
        Request req = new Request();
        req.setType(RequestType.GET_DONATORI);
        return req;
    }

    public static Response createGetDonatoriResponse(List<Donator> donatori) {
        Response resp = new Response();
        resp.setType(ResponseType.GET_DONATIONS);
        resp.setDonatori(donatori);
        return resp;
    }

    public static Request createAddDonatorRequest(Donator donator) {
        Request req = new Request();
        req.setType(RequestType.NEW_DONATOR);
        req.setDonator(donator);
        return req;
    }

    public static Response createNewDonationResponse(Donatie donatie) {
        Response resp = new Response();
        resp.setType(ResponseType.NEW_DONATION);
        resp.setDonatie(donatie);
        return resp;
    }

    public static Response createNewDonatorResponse(Donator donator) {
        Response resp = new Response();
        resp.setType(ResponseType.NEW_DONATOR);
        resp.setDonator(donator);
        return resp;
    }

    public static Request createFindDonatorRequest(Donator donator) {
        Request req = new Request();
        req.setType(RequestType.FIND_DONATOR);
        req.setDonator(donator);
        return req;
    }

    public static Response createFindDonatorResponse(Donator donator) {
        Response resp = new Response();
        resp.setType(ResponseType.FIND_DONATOR);
        resp.setDonator(donator);
        return resp;
    }

    public static Request createNewDonationRequest(Donatie donatie) {
        Request req = new Request();
        req.setType(RequestType.NEW_DONATION);
        req.setDonatie(donatie);
        return req;
    }

    public static Request createFindCauzaRequest(Cauza cauza) {
        Request req = new Request();
        req.setType(RequestType.FIND_CAUZA);
        System.out.println(cauza.getId());
        cauza.setId(0L);
        req.setCauza(cauza);
        return req;
    }

    public static Response createFindCauzaResponse(Cauza cauza) {
        Response resp = new Response();
        resp.setType(ResponseType.FIND_CAUZA);
        resp.setCauza(cauza);
        return resp;
    }
}
