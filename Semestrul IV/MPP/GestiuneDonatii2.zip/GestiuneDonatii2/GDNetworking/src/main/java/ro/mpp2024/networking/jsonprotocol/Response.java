package ro.mpp2024.networking.jsonprotocol;

import ro.mpp2024.model.Cauza;
import ro.mpp2024.model.Donatie;
import ro.mpp2024.model.Donator;
import ro.mpp2024.model.Voluntar;
import ro.mpp2024.networking.dto.DonatieDTO;
import ro.mpp2024.networking.dto.UserDTO;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

public class Response implements Serializable {

    private ResponseType type;
    private String errorMessage;
    private UserDTO voluntar;
    private List<Donator> donatori;
    private HashMap<String, Float> donatii;
    private Donatie donatie;
    private Donator donator;
    private Cauza cauza;

    public Response() {
    }

    public ResponseType getType() {
        return type;
    }

    public void setType(ResponseType type) {
        this.type = type;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public UserDTO getVoluntar() {
        return voluntar;
    }

    public void setVoluntar(UserDTO voluntar) {
        this.voluntar = voluntar;
    }

    public Donatie getDonatie() {
        return donatie;
    }

    public void setDonatie(Donatie donatie) {
        this.donatie = donatie;
    }

    @Override
    public String toString() {
        return "Response{" +
                "type=" + type +
                ", errorMessage='" + errorMessage + '\'' +
                ", voluntar=" + voluntar +
                ", donatieDTO=" + donatie +
                '}';
    }

    public HashMap<String, Float> getDonatii() {
        return donatii;
    }
    public void setDonatii(HashMap<String, Float> donatii) {
        this.donatii = donatii;
    }

    public void setDonatori(List<Donator> donatori) {
        this.donatori = donatori;
    }

    public List<Donator> getDonatori() {
        return donatori;
    }

    public void setDonator(Donator donator) {
        this.donator = donator;
    }

    public Donator getDonator() {
        return this.donator;
    }

    public Cauza getCauza() {
        return this.cauza;
    }

    public void setCauza(Cauza cauza) {
        this.cauza=cauza;
    }
}
