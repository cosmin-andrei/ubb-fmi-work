package ro.mpp2024.networking.jsonprotocol;

public enum ResponseType {

    OK, ERROR, NEW_DONATION, GET_DONATIONS, FIND_DONATOR, FIND_CAUZA, NEW_DONATOR

}

