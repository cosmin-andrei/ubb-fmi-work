﻿using System;
using System.Collections.Generic;
using GestiuneDonatii.model;
using GestiuneDonatii.utils;
using GestiuneDonatii.Repository;
using log4net;
using log4net.Config;

using System.Configuration;

namespace GestiuneDonatii
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //configurare jurnalizare folosind log4net
            XmlConfigurator.Configure(new System.IO.FileInfo("..\\..\\..\\log4net.config"));
            Console.WriteLine("Configuration Settings for donatiiDB {0}",GetConnectionStringByName("donatiiDB"));
            IDictionary<String, string> props = new SortedList<String, String>();
            props.Add("ConnectionString", GetConnectionStringByName("donatiiDB"));

            Console.WriteLine("Teste Cauza repo...");
            CauzaRepo cauzaRepo = new CauzaRepo(props);
            foreach (var cause in cauzaRepo.findAll())
            {
                Console.WriteLine(cause.Nume);
            }

            Console.WriteLine(cauzaRepo.findOne(1L)?.Descriere);
            
            
            Console.WriteLine("Teste Donator repo...");
            DonatorRepo donatorRepo = new DonatorRepo(props);

            // donatorRepo.save(new Donator(1L, "Cosmin", 073894, "Galati"));
            // donatorRepo.save(new Donator(2L, "florentin", 073894, "Cluj"));
            
            foreach (var donator in donatorRepo.findAll())
            {
                Console.WriteLine(donator.Nume);
            }

            Console.WriteLine(donatorRepo.findOne(1L));
            
            Console.WriteLine("Teste Voluntar repo...");
            VoluntarRepo voluntarRepo = new VoluntarRepo(props);
            foreach (var voluntar in voluntarRepo.findAll())
            {
                Console.WriteLine(voluntar.Nume);
            }

            Console.WriteLine(voluntarRepo.findOne(2L).Telefon);

            Console.WriteLine("Teste donatie repo...");
            DonatieRepo donatieRepo = new DonatieRepo(props);
            // Donatie donatiii = new Donatie(1L, donatorRepo.findOne(1L), cauzaRepo.findOne(1L), 500F);
            // donatiii.Data = DateTime.Now;
            // donatieRepo.save(donatiii);
            foreach (var donatie in donatieRepo.findAll())
            {
                Console.WriteLine(donatie.Suma);
            }

        }
        
        static string GetConnectionStringByName(string name)
        {
            // Assume failure.
            string returnValue = null;

            // Look for the name in the connectionStrings section.
            ConnectionStringSettings settings =ConfigurationManager.ConnectionStrings[name];

            // If found, return the connection string.
            if (settings != null)
                returnValue = settings.ConnectionString;

            return returnValue;
        }

    }
}