import { CAUZA_BASE_URL } from './consts';

function status(response) {
    console.log('response status ' + response.status);
    if (response.status >= 200 && response.status < 300) {
        return Promise.resolve(response);
    } else {
        return Promise.reject(new Error(response.statusText));
    }
}

function json(response) {
    return response.json();
}

function handleErrors(error) {
    console.log('Request failed', error);
    // Verificăm dacă eroarea este generată de server
    if (error instanceof Error && error.message.includes("Failed to fetch")) {
        // Afișăm un mesaj corespunzător în caz de eroare de conectare la server
        console.log('Eroare de conexiune la server. Vă rugăm să verificați conexiunea la internet și să încercați din nou.');
    } else {
        // Afișăm eroarea primită de la server
        console.log('Eroare din baza de date:', error.message);
    }
    return Promise.reject(error);
}

export function GetCauze() {
    let headers = new Headers();
    headers.append('Accept', 'application/json');
    let myInit = {
        method: 'GET',
        headers: headers,
        mode: 'cors'
    };
    let request = new Request(CAUZA_BASE_URL, myInit);

    console.log('Inainte de fetch GET pentru ' + CAUZA_BASE_URL);

    return fetch(request)
        .then(status)
        .then(json)
        .then(data => {
            console.log('Request succeeded with JSON response', data);
            return data;
        })
        .catch(handleErrors);
}

export function DeleteCauza(id) {
    console.log('inainte de fetch delete');
    let myHeaders = new Headers();
    myHeaders.append("Accept", "application/json");

    let antet = {
        method: 'DELETE',
        headers: myHeaders,
        mode: 'cors'
    };

    const cauzaDelUrl = CAUZA_BASE_URL + '/' + id;
    console.log('URL pentru delete   ' + cauzaDelUrl);
    return fetch(cauzaDelUrl, antet)
        .then(status)
        .then(response => {
            console.log('Delete status ' + response.status);
            return response.text();
        })
        .catch(handleErrors);
}

export function AddCauza(cauza) {
    console.log('inainte de fetch post' + JSON.stringify(cauza));

    let myHeaders = new Headers();
    myHeaders.append("Accept", "application/json");
    myHeaders.append("Content-Type", "application/json");

    let antet = {
        method: 'POST',
        headers: myHeaders,
        mode: 'cors',
        body: JSON.stringify(cauza)
    };

    return fetch(CAUZA_BASE_URL, antet)
        .then(status)
        .then(response => {
            return response.text();
        })
        .catch(handleErrors);
}

export function UpdateCauza(cauza) {
    console.log('inainte de fetch put' + JSON.stringify(cauza));
    let myHeaders = new Headers();
    myHeaders.append("Accept", "application/json");
    myHeaders.append("Content-Type", "application/json");

    let antet = {
        method: 'PUT',
        headers: myHeaders,
        mode: 'cors',
        body: JSON.stringify(cauza)
    };


    const cauzaDelUrl = CAUZA_BASE_URL + '/' + cauza.id.toString();
    console.log('URL pentru update   ' + cauzaDelUrl);
    return fetch(cauzaDelUrl, antet)
        .then(status)
        .then(response => {
            console.log('Delete status ' + response.status);
            return response.text();
        })
        .catch(handleErrors);

}
