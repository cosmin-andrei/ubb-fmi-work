// eslint-disable-next-line no-unused-vars
import React, {useEffect} from 'react';
import { useState } from 'react';
import CauzaTable from './CauzaTable.jsx';
import './CauzaApp.css'
import CauzaForm from "./CauzaForm.jsx";
import {GetCauze, DeleteCauza, AddCauza, UpdateCauza} from './utils/rest-calls'

export default function CauzaApp(){
    const [cauze, setCauze] = useState([{"id":"1", "nume":"Maria sange", "descriere":"Are nevoie",}]);

    function addFunc(cauza){
        console.log('inside add Func '+cauza);
        AddCauza(cauza)
            .then(() => GetCauze())
            .then(cauze => setCauze(cauze))
            .catch(error => console.log('eroare add ', error));
    }

    function updateFunc(cauza){
        console.log('inside updateFunc '+cauza);
        UpdateCauza(cauza)
            .then(() => GetCauze())
            .then(cauze => setCauze(cauze))
            .catch(error => console.log('eroare update', error));
    }

    function deleteFunc(cauza){
        console.log('inside deleteFunc '+cauza);
        DeleteCauza(cauza)
            .then(() => GetCauze())
            .then(cauze => setCauze(cauze))
            .catch(error => console.log('eroare delete', error));
    }

    useEffect(()=>{
        console.log('inside useEffect');
        GetCauze().then(cauze => setCauze(cauze));
    }, []);

    return (
        <div className="CauzaApp">
            <h1>Aplicatie management cauze</h1>
            <CauzaForm addFunc={addFunc} updateFunc={updateFunc}/>
            <br/>
            <br/>
            <CauzaTable cauze={cauze} deleteFunc={deleteFunc}/>
        </div>
    );
}
