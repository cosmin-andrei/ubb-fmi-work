// eslint-disable-next-line no-unused-vars
import React from 'react';
import PropTypes from 'prop-types';
import './CauzaApp.css'

function CauzaRow({ cauza, deleteFunc }) {
    function handleDelete() {
        console.log('delete button pentru ' + cauza.id);
        deleteFunc(cauza.id.toString());
    }

    return (
        <tr>
            <td>{cauza.id.toString()}</td>
            <td>{cauza.nume}</td>
            <td>{cauza.descriere}</td>
            <td><button onClick={handleDelete}>Delete</button></td>
        </tr>
    );
}

CauzaRow.propTypes = {
    cauza: PropTypes.shape({
        id: PropTypes.string.isRequired,
        nume: PropTypes.string.isRequired,
        descriere: PropTypes.string.isRequired,
    }).isRequired,
    deleteFunc: PropTypes.func.isRequired,
};

export default function CauzaTable({ cauze, deleteFunc }) {
    console.log("In CauzaTable");
    console.log(cauze);
    let rows = [];
    cauze.forEach(function (cauza) {
        rows.push(<CauzaRow cauza={cauza} key={cauza.id.toString()} deleteFunc={deleteFunc} />);
    });

    return (
        <div className="CauzaTable">
            <table className="center">
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Nume</th>
                    <th>Descriere</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>{rows}</tbody>
            </table>
        </div>
    );
}

CauzaTable.propTypes = {
    cauze: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.string.isRequired,
            nume: PropTypes.string.isRequired,
            descriere: PropTypes.string.isRequired,
        })
    ).isRequired,
    deleteFunc: PropTypes.func.isRequired,
};
