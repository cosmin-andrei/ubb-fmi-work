// eslint-disable-next-line no-unused-vars
import React, { useState } from 'react';
import PropTypes from 'prop-types';

export default function CauzaForm({ addFunc, updateFunc, initialValues }) {
    const [id, setId] = useState(initialValues ? initialValues.id : '');
    const [nume, setNume] = useState(initialValues ? initialValues.nume : '');
    const [descriere, setDescriere] = useState(initialValues ? initialValues.descriere : '');

    function handleSubmit(event) {
        event.preventDefault();
        const cauza = {
            id: id,
            nume: nume,
            descriere: descriere
        };

        if (id) {
            updateFunc(cauza);
        } else {
            addFunc(cauza);
        }

        setId('');
        setNume('');
        setDescriere('');
    }

    return (
        <form onSubmit={handleSubmit}>
            <label>
                Id:
                <input type="text" value={id} onChange={e => setId(e.target.value)} />
            </label><br />
            <label>
                Nume:
                <input type="text" value={nume} onChange={e => setNume(e.target.value)} />
            </label><br />
            <label>
                Descriere:
                <input type="text" value={descriere} onChange={e => setDescriere(e.target.value)} />
            </label><br />

            <input type="submit" value={id ? "Update cauza" : "Add cauza"} />
            {id && <button type="button" onClick={() => setId('')}>Cancel</button>}
        </form>
    );
}

CauzaForm.propTypes = {
    addFunc: PropTypes.func.isRequired,
    updateFunc: PropTypes.func.isRequired,
    initialValues: PropTypes.object
};
