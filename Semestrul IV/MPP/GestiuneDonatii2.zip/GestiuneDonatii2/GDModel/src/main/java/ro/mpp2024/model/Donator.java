package ro.mpp2024.model;

import java.io.Serializable;

public class Donator extends Entity<Long> implements Serializable {

    private String adresa;
    private String nume;
    private Long telefon;

    public Donator(String nume, Long telefon, String adresa) {
        this.nume = nume;
        this.telefon = telefon;
        this.adresa = adresa;

    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public Long getTelefon() {
        return telefon;
    }

    public void setTelefon(Long telefon) {
        this.telefon = telefon;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }
}
