package ro.mpp2024.model;

import java.io.Serializable;

public class Cauza extends Entity<Long> implements Serializable {

    private String nume;
    private String descriere;

    public Cauza(String nume, String descriere) {
        this.nume = nume;
        this.descriere = descriere;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }
}
