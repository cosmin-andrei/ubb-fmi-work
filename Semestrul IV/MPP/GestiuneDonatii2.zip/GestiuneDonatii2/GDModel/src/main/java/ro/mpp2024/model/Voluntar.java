package ro.mpp2024.model;

import java.io.Serializable;

public class Voluntar extends Entity<Long> implements Serializable {

    private String username;
    private String email;
    private String parola;
    private String nume;
    private Long telefon;

    public Voluntar(String username, String parola) {
        this.username = username;
        this.parola = parola;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public Long getTelefon() {
        return telefon;
    }

    public void setTelefon(Long telefon) {
        this.telefon = telefon;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getParola() {
        return parola;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }
}
