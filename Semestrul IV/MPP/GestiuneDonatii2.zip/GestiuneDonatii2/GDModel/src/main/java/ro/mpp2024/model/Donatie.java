package ro.mpp2024.model;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDateTime;

public class Donatie extends Entity<Long> implements Serializable {
    private Donator donator;
    private Cauza cauza;
    private Timestamp data;
    private Float suma;

    public Donatie(Donator donator, Cauza cauza, Float suma) {
        this.donator = donator;
        this.cauza = cauza;
        this.data = Timestamp.valueOf(LocalDateTime.now());
        this.suma = suma;
    }

    public Donator getDonator() {
        return donator;
    }

    public void setDonator(Donator donator) {
        this.donator = donator;
    }

    public Cauza getCauza() {
        return cauza;
    }

    public void setCauza(Cauza cauza) {
        this.cauza = cauza;
    }

    public Timestamp getData() {
        return data;
    }

    public void setData(Timestamp data) {
        this.data = data;
    }

    public void setSuma(Float suma) {
        this.suma = suma;
    }

    public float getSuma() {
        return suma;
    }

}
