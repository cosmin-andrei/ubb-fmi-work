package ro.mpp2024;

import ro.mpp2024.networking.utils.AbstractServer;
import ro.mpp2024.networking.utils.GDJsonConcurrentServer;
import ro.mpp2024.repository.CauzaRepo;
import ro.mpp2024.repository.DonatieRepo;
import ro.mpp2024.repository.DonatorRepo;
import ro.mpp2024.repository.VoluntarRepo;
import ro.mpp2024.repository.interfaces.CauzaRepoInterface;
import ro.mpp2024.repository.interfaces.DonatieRepoInterface;
import ro.mpp2024.repository.interfaces.DonatorRepoInterface;
import ro.mpp2024.repository.interfaces.VoluntarRepoInterface;
import ro.mpp2024.server.GDServicesImpl;
import ro.mpp2024.service.IServices;

import java.io.IOException;
import java.rmi.ServerException;
import java.util.Properties;

public class StartJsonServer {
    private static int defaultPort=55555;
    public static void main(String[] args) {

        Properties serverProps=new Properties();
        try {
            serverProps.load(StartJsonServer.class.getResourceAsStream("/server.properties"));
            System.out.println("Server properties set. ");
            serverProps.list(System.out);
        } catch (IOException e) {
            System.err.println("Cannot find properties "+e);
            return;
        }

        DonatorRepoInterface donatorRepo = new DonatorRepo(serverProps);
        DonatieRepoInterface donatieRepo = new DonatieRepo(serverProps);
        CauzaRepoInterface cauzaRepo = new CauzaRepo(serverProps);
        VoluntarRepoInterface voluntarRepo = new VoluntarRepo(serverProps);
        IServices service = new GDServicesImpl(donatorRepo, donatieRepo, cauzaRepo, voluntarRepo);
        int ServerPort=defaultPort;
        try {
            ServerPort = Integer.parseInt(serverProps.getProperty("server.port"));
        }catch (NumberFormatException nef){
            System.err.println("Wrong  Port Number"+nef.getMessage());
            System.err.println("Using default port "+defaultPort);
        }
        System.out.println("Starting server on port: "+ServerPort);
        AbstractServer server = new GDJsonConcurrentServer(ServerPort, service);
        try {
//            Exception in thread "main" java.lang.NullPointerException: Cannot invoke "java.net.ServerSocket.close()" because "this.server" is null
//	at ro.mpp2024.networking.utils.AbstractServer.stop(AbstractServer.java:36)
//	at ro.mpp2024.networking.utils.AbstractServer.start(AbstractServer.java:29)
//	at ro.mpp2024.StartJsonServer.main(StartJsonServer.java:49)
            server.start();
        } catch (ServerException e) {
            System.err.println("Error starting the server" + e.getMessage());
        }
    }
}
