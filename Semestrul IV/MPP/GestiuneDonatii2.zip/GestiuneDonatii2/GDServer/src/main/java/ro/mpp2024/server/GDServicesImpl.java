package ro.mpp2024.server;

import ro.mpp2024.model.Cauza;
import ro.mpp2024.model.Donatie;
import ro.mpp2024.model.Donator;
import ro.mpp2024.model.Voluntar;
import ro.mpp2024.repository.interfaces.CauzaRepoInterface;
import ro.mpp2024.repository.interfaces.DonatieRepoInterface;
import ro.mpp2024.repository.interfaces.DonatorRepoInterface;
import ro.mpp2024.repository.interfaces.VoluntarRepoInterface;
import ro.mpp2024.service.IObserver;
import ro.mpp2024.service.IServices;
import ro.mpp2024.service.ServiceException;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GDServicesImpl implements IServices {

    private DonatorRepoInterface donatorRepo;
    private DonatieRepoInterface donatieRepo;
    private CauzaRepoInterface cauzaRepo;
    private VoluntarRepoInterface voluntarRepo;
    private Map<String, IObserver> loggedClients;

    private List<IObserver> observers;

    public GDServicesImpl(DonatorRepoInterface donatorRepo, DonatieRepoInterface donatieRepo, CauzaRepoInterface cauzaRepo, VoluntarRepoInterface voluntarRepo) {
        this.donatorRepo = donatorRepo;
        this.donatieRepo = donatieRepo;
        this.cauzaRepo = cauzaRepo;
        this.voluntarRepo = voluntarRepo;
        loggedClients = new ConcurrentHashMap<>();
        this.observers = new ArrayList<>();
    }

    @Override
    public synchronized void login(Voluntar voluntar, IObserver client) throws ServiceException {
        Voluntar userR = voluntarRepo.verifyLogin(voluntar.getUsername(), voluntar.getParola()).orElse(null);
        if (userR != null) {
            if (loggedClients.get(userR.getUsername()) != null)
                throw new ServiceException("User already logged in.");
            loggedClients.put(userR.getUsername(), client);
            observers.add(client);
        } else
            throw new ServiceException("Authentication failed.");
    }

    @Override
    ///Donator
    public synchronized void addDonator(Donator donator) {
        UUID uuid = UUID.randomUUID();
        //pentru a reduce lungimea uuid (128 -> 63 biti)
        long id = uuid.getMostSignificantBits() & Long.MAX_VALUE;
        donator.setId(id);
        donatorRepo.save(donator);
        notifyAllNewDonators(donator);
    }

    private final int defaultThreadsNo = 5;

    private final ExecutorService executorService = Executors.newFixedThreadPool(defaultThreadsNo);

    private void notifyAllNewDonators(Donator donator) {
        for (IObserver observer : observers) {
            executorService.execute(() -> {
                try {
                    observer.newDonator(donator);
                } catch (ServiceException e) {
                    System.err.println("Error notifying donator: " + e.getMessage());
                }
            });
        }
    }


    @Override
    public synchronized List<Donator> getDonatori() {
        Iterable<Donator> donators = donatorRepo.findAll();
        return (List<Donator>) donators;
    }

    @Override
    public synchronized Donator findDonator(Donator donator) {
        return donatorRepo.findDonator(donator.getNume()).orElse(null);
    }


    ///Donatie
    @Override
    public synchronized void addDonatie(Donatie donatie) {
        UUID uuid = UUID.randomUUID();
        long id = uuid.getMostSignificantBits() & Long.MAX_VALUE;
        donatie.setId(id);
        donatieRepo.save(donatie);
        notifyAllNewDonations(donatie);
    }

    private void notifyAllNewDonations(Donatie donatie) {
        for (IObserver observer : observers) {
            executorService.execute(() -> {
                try {
                    observer.newDonation(donatie);
                } catch (ServiceException e) {
                    System.err.println("Error notifying donator: " + e.getMessage());
                }
            });
        }
    }

    ///Cauza
    @Override
    public synchronized Cauza findByNume(Cauza cauza) {
        return cauzaRepo.findByNume(cauza.getNume()).orElse(null);
    }

    @Override
    public synchronized void logout(Voluntar voluntar, IObserver client) throws ServiceException {
        IObserver localClient = loggedClients.remove(voluntar.getUsername());
        if (localClient == null)
            throw new ServiceException("User " + voluntar.getId() + " is not logged in.");
    }

    @Override
    public synchronized HashMap<String, Float> getAllDonatii() {
        Map<Cauza, Float> causesSum = new HashMap<>();
        HashMap<String, Float> donatii = new HashMap<>();

        for (Cauza cauza : cauzaRepo.findAll()) {
            causesSum.put(cauza, 0.0f);
        }

        for (Donatie donatie : donatieRepo.findAll()) {
            Cauza cauza = donatie.getCauza();
            float suma = donatie.getSuma();
            causesSum.put(cauza, causesSum.get(cauza) + suma);
        }

        for (Cauza cauza : causesSum.keySet()) {
            donatii.put(cauza.getNume(), causesSum.get(cauza));
        }

        return donatii;
    }
}
