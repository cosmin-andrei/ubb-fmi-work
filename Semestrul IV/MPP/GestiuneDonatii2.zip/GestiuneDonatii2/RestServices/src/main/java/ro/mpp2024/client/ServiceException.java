package ro.mpp2024.client;

public class ServiceException extends Throwable {
    public ServiceException(Exception e) {
        super(e);
    }

    public ServiceException(String message) {
        super(message);
    }
}
