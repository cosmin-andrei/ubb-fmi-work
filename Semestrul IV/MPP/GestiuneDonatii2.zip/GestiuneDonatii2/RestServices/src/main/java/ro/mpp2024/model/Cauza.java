package ro.mpp2024.model;

import jakarta.persistence.*;
import jakarta.persistence.Entity;

import java.io.Serializable;

@Entity
@Table(name = "Cauza")
public class Cauza implements Serializable, ro.mpp2024.model.Entity<Long> {

    private Long id;

    @Column(name = "nume")
    private String nume;

    @Column(name = "descriere")
    private String descriere;

    public Cauza() {
        // Constructor necesar pentru Hibernate
    }

    public Cauza(String nume, String descriere) {
        this.nume = nume;
        this.descriere = descriere;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    @Id
    @GeneratedValue(generator = "increment")
    public Long getId() {
        return id;
    }

    public String getNume() {
        return nume;
    }

    public String getDescriere() {
        return descriere;
    }
}
