package ro.mpp2024.client;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import ro.mpp2024.model.Cauza;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.Callable;

public class CausesClient {

    public static final String URL = "http://localhost:8080/cauza";

    private RestTemplate restTemplate = new RestTemplate();

    public void receiveUpdates() throws Exception {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        channel.queueDeclare("updates", false, false, false, null);
        channel.basicConsume("updates", true, (consumerTag, delivery) -> {
            String message = new String(delivery.getBody(), StandardCharsets.UTF_8);
            System.out.println("Received update: " + message);
        }, consumerTag -> {});
    }

    private <T> T execute(Callable<T> callable) throws ServiceException {
        try {
            return callable.call();
        } catch (ResourceAccessException | HttpClientErrorException e) { // server down, resource exception
            throw new ServiceException(e);
        } catch (Exception e) {
            throw new ServiceException(e);
        }
    }

    public Cauza[] getAll() throws ServiceException {
        return execute(() -> restTemplate.getForObject(URL, Cauza[].class));
    }

    public Cauza getById(Long id) throws Exception, ServiceException {
        return execute(() -> restTemplate.getForObject(String.format("%s/%s", URL, id), Cauza.class));
    }

    public Cauza create(Cauza cauza) throws Exception, ServiceException {
        return execute(() -> restTemplate.postForObject(URL, cauza, Cauza.class));
    }

    public void update(Cauza cauza) throws ServiceException {
        execute(() -> {
            restTemplate.put(String.format("%s/%s", URL, cauza.getId()), cauza);
            return null;
        });
    }


    public void delete(Long id) throws ServiceException {
        execute(() -> {
            restTemplate.delete(String.format("%s/%s", URL, id));
            return null;
        });
    }


}

