package ro.mpp2024.repository;

import org.hibernate.Session;
import org.springframework.stereotype.Component;
import ro.mpp2024.model.Cauza;
import ro.mpp2024.repository.interfaces.CauzaRepoInterface;

import java.util.Optional;

@Component
public class CauzaHibernateRepo implements CauzaRepoInterface {

    @Override
    public Optional<Cauza> findOne(Long id) {
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            return Optional.ofNullable(session.get(Cauza.class, id));
        }
    }

    @Override
    public Iterable<Cauza> findAll() {
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            return session.createQuery("from Cauza", Cauza.class).getResultList();
        }catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Optional<Cauza> save(Cauza entity) {
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            session.beginTransaction();

            Cauza existingCauza = session.createQuery("from Cauza where lower(nume) = :nume", Cauza.class)
                    .setParameter("nume", entity.getNume().toLowerCase())
                    .uniqueResult();
            if (existingCauza != null) {
                // Dacă există deja o cauză cu același nume, nu permitem salvarea și returnăm Optional.empty()
                return Optional.empty();
            }

            // Dacă nu există o cauză cu același nume, continuăm cu salvarea cauzei noi
            Long id = (Long) session.save(entity);
            session.getTransaction().commit();
            return findOne(id);
        }
    }


    @Override
    public Optional<Cauza> delete(Long id) {
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            session.beginTransaction();
            Cauza cauza = session.get(Cauza.class, id);
            if (cauza != null) {
                session.delete(cauza);
            }
            session.getTransaction().commit();
            return Optional.ofNullable(cauza);
        }
    }

    @Override
    public Optional<Cauza> update(Cauza entity) {
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            session.beginTransaction();
            session.update(entity);
            session.getTransaction().commit();
            return Optional.of(entity);
        }
    }

    @Override
    public Optional<Cauza> findByNume(String nume) {
        try (Session session = HibernateUtils.getSessionFactory().openSession()) {
            return session.createQuery("from Cauza where nume = :nume", Cauza.class)
                    .setParameter("nume", nume)
                    .uniqueResultOptional();
        }
    }
}
