package ro.mpp2024;

import ro.mpp2024.client.CausesClient;
import ro.mpp2024.client.ServiceException;
import ro.mpp2024.model.Cauza;

import java.util.Arrays;
import java.util.List;

public class StartRestClient {
    private final static CausesClient restClient = new CausesClient();
    private static Cauza updatedCause = null;

    public static void main(String[] args) {
        Cauza newCauza = new Cauza("Asociatia ONedu", "ONEDU ONEDU ONEDU");
        newCauza.setId(100L);

        new Thread(() -> {
            try {
                restClient.receiveUpdates();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();

        try {
            show(() -> {
                System.out.println("\n\nTest create:\n\n");
                try {
                    Cauza result = restClient.create(newCauza);
                    System.out.println(result);
                    setCreatedCause(result);
                } catch (ServiceException | Exception e) {
                    e.printStackTrace();
                }
            });

            show(() -> {
                System.out.println("\n\nTest find all\n\n");
                try {
                    List<Cauza> result = Arrays.asList(restClient.getAll());
                    for (Cauza c : result) {
                        System.out.println(c.getNume() + " " + c.getDescriere());
                    }
                } catch (ServiceException e) {
                    e.printStackTrace();
                }
            });

            show(() -> {
                System.out.println("\n\nTest find by ID\n\n");
                try {
                    System.out.println(restClient.getById(1L));
//                    System.out.println(restClient.getById(updatedCause.getId()));
                } catch (ServiceException | Exception e) {
                    e.printStackTrace();
                }
            });

            show(() -> {
                System.out.println("\n\nTest update\n\n");
                updatedCause.setDescriere("Maria are nevoie de sange si de bani");
                try {
                    restClient.update(updatedCause);
                } catch (ServiceException e) {
                    throw new RuntimeException(e);
                }
            });

            show(() -> {
                System.out.println("\n\nTest delete\n\n");
                try {
                    restClient.delete(updatedCause.getId());
                } catch (ServiceException e) {
                    e.printStackTrace();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void show(Runnable task) {
        try {
            task.run();
        } catch (Exception e) {
            System.out.println("Services exception: " + e);
        }
    }

    private static void setCreatedCause(Cauza cause) {
        updatedCause = cause;
    }
}
