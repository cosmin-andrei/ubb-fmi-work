package ro.mpp2024.controller;

import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ro.mpp2024.model.Cauza;
import ro.mpp2024.repository.CauzaHibernateRepo;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("cauza")
@CrossOrigin(origins = "http://localhost:5173")
@AllArgsConstructor
public class CauseController {

    private static final String template = "Hello, %s!";

    @Autowired
    private CauzaHibernateRepo cauzaRepo;

    @RequestMapping("/greeting")
    public String greeting(@RequestParam(value = "name", defaultValue = "World") String name) {
        return String.format(template, name);
    }

    @RequestMapping(method = RequestMethod.GET)
    public List<Cauza> getAll() {
        System.out.println("Get all causes ...");
        return (List<Cauza>) cauzaRepo.findAll();
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public ResponseEntity<?> getById(@PathVariable Long id) {
        System.out.println("Get by id " + id);
        Optional<Cauza> cauza = cauzaRepo.findOne(id);
        return cauza.map(c -> ResponseEntity.ok().body(c))
                .orElse(ResponseEntity.notFound().build());
    }

    @RequestMapping(method = RequestMethod.POST)
    public Cauza create(@RequestBody Cauza cauza) {
        System.out.println("Create cauza " + cauza);
        Optional<Cauza> result = cauzaRepo.save(cauza);
        return result.orElse(null);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
    public Cauza update(@PathVariable Long id, @RequestBody Cauza cauza) {
        System.out.println("Update cauza " + cauza);
        cauza.setId(id);
        Optional<Cauza> result = cauzaRepo.update(cauza);
        return result.orElse(null);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<?> delete(@PathVariable Long id) {
        System.out.println("Delete cauza " + id);
        Optional<Cauza> result = cauzaRepo.delete(id);
        if (result.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().build();
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public String causeError(Exception e) {
        return e.getMessage();
    }
}




