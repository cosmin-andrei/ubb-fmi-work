package ro.mpp2024.service;

import ro.mpp2024.model.Cauza;
import ro.mpp2024.model.Donatie;
import ro.mpp2024.model.Donator;
import ro.mpp2024.model.Voluntar;

import java.util.HashMap;
import java.util.List;

public interface IServices {

    void login(Voluntar voluntar, IObserver client) throws ServiceException;
    void addDonator(Donator donator) throws ServiceException;
    List<Donator> getDonatori() throws ServiceException;
    Donator findDonator(Donator donator) throws ServiceException;
    void addDonatie(Donatie donatie) throws ServiceException;
    Cauza findByNume(Cauza cauza) throws ServiceException;
    void logout(Voluntar voluntar, IObserver client) throws ServiceException;
    HashMap<String, Float> getAllDonatii() throws ServiceException;
}
