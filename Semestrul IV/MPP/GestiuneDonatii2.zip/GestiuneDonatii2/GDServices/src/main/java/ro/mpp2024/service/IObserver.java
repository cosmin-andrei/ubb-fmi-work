package ro.mpp2024.service;

import ro.mpp2024.model.Donatie;
import ro.mpp2024.model.Donator;

public interface IObserver {

    void newDonation(Donatie donatie) throws ServiceException;
    void newDonator(Donator donator) throws ServiceException;

}
