#pragma once
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
/*
* Elimina spatiile si caracterele \n dintr-un
* @param str: string dat
*/
void trimTrailing(char* str);